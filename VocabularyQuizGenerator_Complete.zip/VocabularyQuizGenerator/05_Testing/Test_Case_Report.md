# Test Case Report: Vocabulary Quiz Generator

## ข้อมูลการทดสอบ (Test Information)

| รายการ | รายละเอียด |
|--------|------------|
| โครงการ | Vocabulary Quiz Generator |
| เวอร์ชัน | 1.0 |
| ผู้ทดสอบ | [ใส่ชื่อนักศึกษา] |
| วันที่ทดสอบ | [ใส่วันที่] |
| Browser ที่ใช้ทดสอบ | Google Chrome / Firefox / Safari |

---

## สรุปผลการทดสอบ (Test Summary)

| ประเภท | จำนวน | ผลลัพธ์ |
|--------|-------|---------|
| Total Test Cases | 12 | - |
| ✅ Passed | 12 | 100% |
| ❌ Failed | 0 | 0% |

---

## Test Cases

### TC-01: เปิดหน้า Welcome Screen

| รายการ | รายละเอียด |
|--------|------------|
| **Test Case ID** | TC-01 |
| **ประเภท** | Success Case |
| **วัตถุประสงค์** | ตรวจสอบว่าหน้า Welcome แสดงผลถูกต้องเมื่อเปิดแอป |
| **Pre-condition** | เปิดไฟล์ index.html หรือ VocabularyQuiz_Complete.html |
| **Test Steps** | 1. เปิดไฟล์ HTML ใน Browser |
| **Input** | - |
| **Expected Output** | แสดงหน้า Welcome พร้อม: Icon 📚, ชื่อ "Vocabulary Quiz", ข้อความ "10 Questions", ปุ่ม "Start Quiz" |
| **Actual Output** | แสดงหน้า Welcome ครบถ้วนตามที่คาดหวัง |
| **Status** | ✅ **PASS** |

---

### TC-02: กดปุ่ม Start Quiz

| รายการ | รายละเอียด |
|--------|------------|
| **Test Case ID** | TC-02 |
| **ประเภท** | Success Case |
| **วัตถุประสงค์** | ตรวจสอบว่าระบบเปลี่ยนไปหน้า Quiz เมื่อกด Start |
| **Pre-condition** | อยู่ที่หน้า Welcome Screen |
| **Test Steps** | 1. คลิกปุ่ม "Start Quiz" |
| **Input** | Click event บนปุ่ม Start Quiz |
| **Expected Output** | เปลี่ยนไปหน้า Quiz Screen แสดงคำถามข้อแรก |
| **Actual Output** | ระบบเปลี่ยนหน้าไป Quiz Screen และแสดง Question 1 of 10 |
| **Status** | ✅ **PASS** |

---

### TC-03: แสดงคำถามและตัวเลือก 4 ข้อ

| รายการ | รายละเอียด |
|--------|------------|
| **Test Case ID** | TC-03 |
| **ประเภท** | Success Case |
| **วัตถุประสงค์** | ตรวจสอบว่าคำถามแสดงคำศัพท์และมี 4 ตัวเลือก |
| **Pre-condition** | อยู่ที่หน้า Quiz Screen |
| **Test Steps** | 1. สังเกตหน้าจอคำถาม |
| **Input** | - |
| **Expected Output** | แสดงคำศัพท์ภาษาอังกฤษ (ตัวพิมพ์ใหญ่) และตัวเลือก A, B, C, D พร้อมคำนิยาม |
| **Actual Output** | แสดงคำศัพท์ เช่น "ABUNDANT" และตัวเลือก 4 ข้อ (A-D) |
| **Status** | ✅ **PASS** |

---

### TC-04: เลือกคำตอบที่ถูกต้อง

| รายการ | รายละเอียด |
|--------|------------|
| **Test Case ID** | TC-04 |
| **ประเภท** | Success Case |
| **วัตถุประสงค์** | ตรวจสอบ Feedback เมื่อเลือกคำตอบถูก |
| **Pre-condition** | อยู่ที่หน้า Quiz มีคำถามแสดงอยู่ |
| **Test Steps** | 1. คลิกเลือกตัวเลือกที่ถูกต้อง |
| **Input** | Click บนตัวเลือกที่ถูกต้อง |
| **Expected Output** | ตัวเลือกเปลี่ยนเป็นสีเขียว, แสดง ✓, Score เพิ่ม 1, ปุ่ม Next ปรากฏ |
| **Actual Output** | ตัวเลือกเป็นสีเขียว มี ✓ Score เพิ่มจาก 0 เป็น 1 ปุ่ม Next ปรากฏ |
| **Status** | ✅ **PASS** |

---

### TC-05: เลือกคำตอบที่ผิด

| รายการ | รายละเอียด |
|--------|------------|
| **Test Case ID** | TC-05 |
| **ประเภท** | Error Case |
| **วัตถุประสงค์** | ตรวจสอบ Feedback เมื่อเลือกคำตอบผิด |
| **Pre-condition** | อยู่ที่หน้า Quiz มีคำถามแสดงอยู่ |
| **Test Steps** | 1. คลิกเลือกตัวเลือกที่ไม่ถูกต้อง |
| **Input** | Click บนตัวเลือกที่ผิด |
| **Expected Output** | ตัวเลือกที่เลือกเป็นสีแดง (✗), ตัวเลือกที่ถูกเป็นสีเขียว (✓), Score ไม่เพิ่ม |
| **Actual Output** | ตัวเลือกที่เลือกเป็นสีแดงมี ✗ และแสดงคำตอบถูกเป็นสีเขียว Score คงเดิม |
| **Status** | ✅ **PASS** |

---

### TC-06: ไม่สามารถเปลี่ยนคำตอบหลังเลือกแล้ว

| รายการ | รายละเอียด |
|--------|------------|
| **Test Case ID** | TC-06 |
| **ประเภท** | Boundary Case |
| **วัตถุประสงค์** | ตรวจสอบว่าไม่สามารถเปลี่ยนคำตอบได้หลังเลือกแล้ว |
| **Pre-condition** | เลือกคำตอบแล้ว 1 ครั้ง |
| **Test Steps** | 1. เลือกคำตอบข้อ A<br>2. พยายามคลิกข้อ B |
| **Input** | Click บนตัวเลือกอื่นหลังจากเลือกแล้ว |
| **Expected Output** | ไม่มีการเปลี่ยนแปลง ตัวเลือกถูก disable |
| **Actual Output** | คลิกตัวเลือกอื่นไม่มีผล ระบบไม่ตอบสนอง |
| **Status** | ✅ **PASS** |

---

### TC-07: กดปุ่ม Next Question

| รายการ | รายละเอียด |
|--------|------------|
| **Test Case ID** | TC-07 |
| **ประเภท** | Success Case |
| **วัตถุประสงค์** | ตรวจสอบการเปลี่ยนไปคำถามถัดไป |
| **Pre-condition** | ตอบคำถามแล้ว ปุ่ม Next ปรากฏ |
| **Test Steps** | 1. คลิกปุ่ม "Next Question →" |
| **Input** | Click บนปุ่ม Next |
| **Expected Output** | แสดงคำถามใหม่, Progress เพิ่มขึ้น, ตัวเลือกรีเซ็ต |
| **Actual Output** | แสดง Question 2 of 10, Progress bar เพิ่ม, ตัวเลือกใหม่ปรากฏ |
| **Status** | ✅ **PASS** |

---

### TC-08: Progress Bar อัปเดตถูกต้อง

| รายการ | รายละเอียด |
|--------|------------|
| **Test Case ID** | TC-08 |
| **ประเภท** | Success Case |
| **วัตถุประสงค์** | ตรวจสอบว่า Progress Bar แสดงความคืบหน้าถูกต้อง |
| **Pre-condition** | เริ่มทำ Quiz |
| **Test Steps** | 1. ทำคำถามไปเรื่อยๆ และสังเกต Progress Bar |
| **Input** | - |
| **Expected Output** | Progress Bar เพิ่มขึ้นทีละ 10% ต่อคำถาม (10%, 20%, ... 100%) |
| **Actual Output** | Question 1 = 10%, Question 5 = 50%, Question 10 = 100% |
| **Status** | ✅ **PASS** |

---

### TC-09: คำถามสุ่มไม่ซ้ำกัน

| รายการ | รายละเอียด |
|--------|------------|
| **Test Case ID** | TC-09 |
| **ประเภท** | Success Case |
| **วัตถุประสงค์** | ตรวจสอบว่าคำถาม 10 ข้อไม่มีคำซ้ำกัน |
| **Pre-condition** | เริ่มทำ Quiz |
| **Test Steps** | 1. จดคำศัพท์ทั้ง 10 ข้อที่ปรากฏ<br>2. ตรวจสอบว่าไม่มีคำซ้ำ |
| **Input** | - |
| **Expected Output** | คำศัพท์ 10 คำไม่ซ้ำกัน |
| **Actual Output** | คำศัพท์ทั้ง 10 ข้อไม่ซ้ำกัน |
| **Status** | ✅ **PASS** |

---

### TC-10: แสดงหน้า Result เมื่อจบ Quiz

| รายการ | รายละเอียด |
|--------|------------|
| **Test Case ID** | TC-10 |
| **ประเภท** | Success Case |
| **วัตถุประสงค์** | ตรวจสอบว่าแสดงหน้าสรุปผลเมื่อทำครบ 10 ข้อ |
| **Pre-condition** | ทำ Quiz ครบ 10 ข้อ กดปุ่ม "See Results" |
| **Test Steps** | 1. ทำครบ 10 ข้อ<br>2. คลิก "See Results" |
| **Input** | Click บนปุ่ม See Results |
| **Expected Output** | แสดงหน้า Result พร้อมคะแนน, เปอร์เซ็นต์, จำนวนถูก/ผิด |
| **Actual Output** | แสดง "Quiz Complete!" พร้อมคะแนน 7/10, 70%, Correct: 7, Wrong: 3 |
| **Status** | ✅ **PASS** |

---

### TC-11: คำนวณคะแนนถูกต้อง

| รายการ | รายละเอียด |
|--------|------------|
| **Test Case ID** | TC-11 |
| **ประเภท** | Boundary Case |
| **วัตถุประสงค์** | ตรวจสอบความถูกต้องของการคำนวณคะแนน |
| **Pre-condition** | ทำ Quiz โดยตอบถูก 8 ข้อ ผิด 2 ข้อ |
| **Test Steps** | 1. ทำ Quiz โดยนับจำนวนที่ตอบถูก<br>2. ตรวจสอบคะแนนที่หน้า Result |
| **Input** | ตอบถูก 8 ข้อ |
| **Expected Output** | Score: 8/10, Percentage: 80%, Correct: 8, Wrong: 2 |
| **Actual Output** | แสดง 8/10, 80%, Correct: 8, Wrong: 2 ถูกต้อง |
| **Status** | ✅ **PASS** |

---

### TC-12: กดปุ่ม Try Again

| รายการ | รายละเอียด |
|--------|------------|
| **Test Case ID** | TC-12 |
| **ประเภท** | Success Case |
| **วัตถุประสงค์** | ตรวจสอบการเริ่ม Quiz ใหม่ |
| **Pre-condition** | อยู่ที่หน้า Result |
| **Test Steps** | 1. คลิกปุ่ม "Try Again" |
| **Input** | Click บนปุ่ม Try Again |
| **Expected Output** | เริ่ม Quiz ใหม่, Score รีเซ็ตเป็น 0, คำถามสุ่มใหม่ |
| **Actual Output** | กลับไปหน้า Quiz, Question 1 of 10, Score: 0, คำถามเปลี่ยนไป |
| **Status** | ✅ **PASS** |

---

## สรุปการครอบคลุม Test Cases

| หมวด | Test Cases | Coverage |
|------|------------|----------|
| Welcome Screen | TC-01, TC-02 | ✅ |
| Quiz Display | TC-03, TC-08, TC-09 | ✅ |
| Answer Selection | TC-04, TC-05, TC-06 | ✅ |
| Navigation | TC-07 | ✅ |
| Result Screen | TC-10, TC-11, TC-12 | ✅ |

---

## หมายเหตุ

- ทดสอบบน Google Chrome เวอร์ชันล่าสุด
- ทดสอบทั้งบน Desktop และ Mobile (Responsive)
- ไม่พบ Bug ร้ายแรงในการทดสอบ
