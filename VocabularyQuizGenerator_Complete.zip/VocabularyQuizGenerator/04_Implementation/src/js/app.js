/**
 * Vocabulary Quiz Generator - Main Application
 * A simple quiz app to test English vocabulary knowledge
 */

// ==================== CONFIGURATION ====================
const CONFIG = {
    TOTAL_QUESTIONS: 10,
    OPTIONS_PER_QUESTION: 4
};

// ==================== QUIZ STATE ====================
let quizState = {
    questions: [],
    currentIndex: 0,
    score: 0,
    answered: false,
    selectedIndex: null
};

// ==================== UTILITY FUNCTIONS ====================

/**
 * Shuffle array using Fisher-Yates algorithm
 * @param {Array} array - Array to shuffle
 * @returns {Array} - Shuffled array
 */
function shuffleArray(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

/**
 * Get random items from array
 * @param {Array} array - Source array
 * @param {number} count - Number of items to get
 * @param {Array} exclude - Items to exclude
 * @returns {Array} - Random items
 */
function getRandomItems(array, count, exclude = []) {
    const filtered = array.filter(item => !exclude.includes(item));
    const shuffled = shuffleArray(filtered);
    return shuffled.slice(0, count);
}

// ==================== QUESTION GENERATION ====================

/**
 * Generate a single question object
 * @param {Object} correctWord - The correct vocabulary word object
 * @param {Array} allWords - All vocabulary words for wrong options
 * @returns {Object} - Question object
 */
function generateQuestion(correctWord, allWords) {
    // Get 3 wrong definitions
    const wrongWords = getRandomItems(allWords, CONFIG.OPTIONS_PER_QUESTION - 1, [correctWord]);
    const wrongDefinitions = wrongWords.map(w => w.definition);
    
    // Combine correct and wrong definitions
    const allOptions = [correctWord.definition, ...wrongDefinitions];
    const shuffledOptions = shuffleArray(allOptions);
    
    // Find index of correct answer after shuffle
    const correctIndex = shuffledOptions.indexOf(correctWord.definition);
    
    return {
        word: correctWord.word,
        correctAnswer: correctWord.definition,
        options: shuffledOptions,
        correctIndex: correctIndex
    };
}

/**
 * Generate all questions for the quiz
 * @returns {Array} - Array of question objects
 */
function generateQuestions() {
    const selectedWords = getRandomItems(vocabularyData, CONFIG.TOTAL_QUESTIONS);
    return selectedWords.map(word => generateQuestion(word, vocabularyData));
}

// ==================== UI RENDERING ====================

/**
 * Show specific screen and hide others
 * @param {string} screenId - ID of screen to show
 */
function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });
    document.getElementById(screenId).classList.add('active');
}

/**
 * Update progress bar and text
 */
function updateProgress() {
    const current = quizState.currentIndex + 1;
    const total = CONFIG.TOTAL_QUESTIONS;
    const percentage = (current / total) * 100;
    
    document.getElementById('progressText').textContent = `Question ${current} of ${total}`;
    document.getElementById('scoreText').textContent = `Score: ${quizState.score}`;
    document.getElementById('progressFill').style.width = `${percentage}%`;
}

/**
 * Render current question
 */
function renderQuestion() {
    const question = quizState.questions[quizState.currentIndex];
    
    // Update word display
    document.getElementById('wordDisplay').textContent = question.word;
    
    // Update options
    const optionsContainer = document.getElementById('optionsContainer');
    optionsContainer.innerHTML = '';
    
    const letters = ['A', 'B', 'C', 'D'];
    
    question.options.forEach((option, index) => {
        const optionElement = document.createElement('div');
        optionElement.className = 'option';
        optionElement.setAttribute('data-index', index);
        optionElement.onclick = () => selectOption(index);
        
        optionElement.innerHTML = `
            <span class="option-letter">${letters[index]}</span>
            <span class="option-text">${option}</span>
        `;
        
        optionsContainer.appendChild(optionElement);
    });
    
    // Hide next button initially
    document.getElementById('nextBtn').style.display = 'none';
    
    // Update progress
    updateProgress();
    
    // Reset state
    quizState.answered = false;
    quizState.selectedIndex = null;
}

/**
 * Handle option selection
 * @param {number} index - Index of selected option
 */
function selectOption(index) {
    // Prevent multiple selections
    if (quizState.answered) return;
    
    quizState.answered = true;
    quizState.selectedIndex = index;
    
    const question = quizState.questions[quizState.currentIndex];
    const isCorrect = index === question.correctIndex;
    
    // Update score
    if (isCorrect) {
        quizState.score++;
        document.getElementById('scoreText').textContent = `Score: ${quizState.score}`;
    }
    
    // Update UI
    const options = document.querySelectorAll('.option');
    
    options.forEach((option, i) => {
        option.classList.add('disabled');
        
        if (i === question.correctIndex) {
            option.classList.add('correct');
            option.querySelector('.option-letter').textContent = '✓';
        } else if (i === index && !isCorrect) {
            option.classList.add('wrong');
            option.querySelector('.option-letter').textContent = '✗';
        }
    });
    
    // Show next button
    const nextBtn = document.getElementById('nextBtn');
    nextBtn.style.display = 'block';
    
    // Update button text for last question
    if (quizState.currentIndex === CONFIG.TOTAL_QUESTIONS - 1) {
        nextBtn.textContent = 'See Results';
    } else {
        nextBtn.textContent = 'Next Question →';
    }
}

/**
 * Go to next question or show results
 */
function nextQuestion() {
    if (quizState.currentIndex < CONFIG.TOTAL_QUESTIONS - 1) {
        quizState.currentIndex++;
        renderQuestion();
    } else {
        showResults();
    }
}

/**
 * Show final results screen
 */
function showResults() {
    const score = quizState.score;
    const total = CONFIG.TOTAL_QUESTIONS;
    const percentage = Math.round((score / total) * 100);
    const wrong = total - score;
    
    // Update result display
    document.getElementById('finalScore').textContent = `${score}/${total}`;
    document.getElementById('percentage').textContent = `${percentage}%`;
    document.getElementById('correctCount').textContent = score;
    document.getElementById('wrongCount').textContent = wrong;
    
    // Update emoji based on score
    const emoji = document.getElementById('resultEmoji');
    if (percentage >= 80) {
        emoji.textContent = '🎉';
    } else if (percentage >= 60) {
        emoji.textContent = '👍';
    } else if (percentage >= 40) {
        emoji.textContent = '💪';
    } else {
        emoji.textContent = '📚';
    }
    
    showScreen('resultScreen');
}

// ==================== QUIZ CONTROL ====================

/**
 * Start a new quiz
 */
function startQuiz() {
    // Reset state
    quizState = {
        questions: generateQuestions(),
        currentIndex: 0,
        score: 0,
        answered: false,
        selectedIndex: null
    };
    
    // Show quiz screen
    showScreen('quizScreen');
    
    // Render first question
    renderQuestion();
}

/**
 * Restart the quiz
 */
function restartQuiz() {
    startQuiz();
}

// ==================== INITIALIZATION ====================

/**
 * Initialize the app
 */
function init() {
    // Update total questions display
    document.getElementById('totalQuestions').textContent = `${CONFIG.TOTAL_QUESTIONS} Questions`;
    
    // Show welcome screen
    showScreen('welcomeScreen');
    
    console.log('Vocabulary Quiz Generator initialized!');
    console.log(`Total words in database: ${vocabularyData.length}`);
}

// Start app when DOM is loaded
document.addEventListener('DOMContentLoaded', init);
