// Vocabulary Data - 60 English Words with Definitions
// Format: { word: "WORD", definition: "definition text" }

const vocabularyData = [
    // Basic Level (1-20)
    { word: "ABANDON", definition: "To leave someone or something completely" },
    { word: "ABUNDANT", definition: "Existing in large quantities; plentiful" },
    { word: "ACCURATE", definition: "Correct and exact in every detail" },
    { word: "ACHIEVE", definition: "To successfully complete something or reach a goal" },
    { word: "ADAPT", definition: "To change behavior or ideas to fit a new situation" },
    { word: "ADEQUATE", definition: "Enough or satisfactory for a particular purpose" },
    { word: "ADMIRE", definition: "To respect and approve of someone or something" },
    { word: "ANXIOUS", definition: "Feeling worried or nervous about something" },
    { word: "APPARENT", definition: "Clearly visible or understood; obvious" },
    { word: "APPROACH", definition: "To come near or nearer to something or someone" },
    { word: "ASSUME", definition: "To accept something as true without proof" },
    { word: "BENEFIT", definition: "An advantage or profit gained from something" },
    { word: "BRIEF", definition: "Lasting only a short time; concise" },
    { word: "CAPABLE", definition: "Having the ability or qualities to do something" },
    { word: "CAPTURE", definition: "To take someone or something by force" },
    { word: "CEASE", definition: "To stop happening or existing" },
    { word: "CHALLENGE", definition: "A difficult task that tests someone's abilities" },
    { word: "CLARIFY", definition: "To make something easier to understand" },
    { word: "COLLAPSE", definition: "To fall down or break into pieces suddenly" },
    { word: "COMMIT", definition: "To promise to do something or give your loyalty" },

    // Intermediate Level (21-40)
    { word: "COMPEL", definition: "To force someone to do something" },
    { word: "COMPLEX", definition: "Consisting of many different connected parts" },
    { word: "CONCLUDE", definition: "To bring something to an end; to decide" },
    { word: "CONFLICT", definition: "A serious disagreement or argument" },
    { word: "CONSCIOUS", definition: "Aware of and responding to one's surroundings" },
    { word: "CONSTANT", definition: "Happening all the time or repeatedly" },
    { word: "CONTRIBUTE", definition: "To give something to help achieve a goal" },
    { word: "CONVINCE", definition: "To make someone believe something is true" },
    { word: "CRUCIAL", definition: "Extremely important or necessary" },
    { word: "CURIOUS", definition: "Eager to know or learn something" },
    { word: "DECLINE", definition: "To become smaller, weaker, or less" },
    { word: "DEFINE", definition: "To explain the meaning of a word or concept" },
    { word: "DEMONSTRATE", definition: "To show clearly that something exists or is true" },
    { word: "DENY", definition: "To refuse to admit or accept something" },
    { word: "DETECT", definition: "To discover or notice something" },
    { word: "DETERMINE", definition: "To decide or settle something conclusively" },
    { word: "DEVOTE", definition: "To give all of something to a particular purpose" },
    { word: "DISTINCT", definition: "Clearly different or separate from others" },
    { word: "DIVERSE", definition: "Showing a great deal of variety; different" },
    { word: "DOMINANT", definition: "Having power and influence over others" },

    // Advanced Level (41-60)
    { word: "ELABORATE", definition: "Involving many carefully arranged parts; detailed" },
    { word: "EMERGE", definition: "To come out from a hidden or enclosed place" },
    { word: "EMPHASIZE", definition: "To give special importance to something" },
    { word: "ENABLE", definition: "To make it possible for someone to do something" },
    { word: "ENCOUNTER", definition: "To unexpectedly meet someone or experience something" },
    { word: "ENHANCE", definition: "To improve the quality or value of something" },
    { word: "ENORMOUS", definition: "Extremely large in size or amount" },
    { word: "ENSURE", definition: "To make certain that something happens" },
    { word: "ESTABLISH", definition: "To set up or create something permanently" },
    { word: "EVALUATE", definition: "To judge or assess the value of something" },
    { word: "EVIDENT", definition: "Clearly seen or understood; obvious" },
    { word: "EXCEED", definition: "To go beyond what is allowed or expected" },
    { word: "EXCLUDE", definition: "To deliberately not include something" },
    { word: "EXPAND", definition: "To become or make larger in size or amount" },
    { word: "EXPOSE", definition: "To uncover or reveal something hidden" },
    { word: "EXTEND", definition: "To make something longer or larger" },
    { word: "EXTRACT", definition: "To remove or take out something" },
    { word: "FACILITATE", definition: "To make an action or process easier" },
    { word: "FAMILIAR", definition: "Well known from long experience" },
    { word: "FEASIBLE", definition: "Possible and practical to do easily" }
];

// Export for use in app.js
if (typeof module !== 'undefined' && module.exports) {
    module.exports = vocabularyData;
}
